import pygame 
import random

pygame.init()


screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption("TWO SPRITES WITH CUSTOM EVENT")

CHANGE_COLOR = pygame.USEREVENT + 1
pygame.time.set_timer((CHANGE_COLOR, 1000)

class BOx(pygame.sprite.sprite):
  def __init__(self, x, y, color):
    
    super().__init__()
    self.image = pygame.surface((80, 80))
    self.image.FILL(color)
    self.rect = self.image.get_rect()
    self.rect.topleft = (x,y)
    
  def change_color(self):
    new_color=(
      random.randint(0,255),
      random.randint(0,255),
                 random.randint(0,255)
self.image.fill(new_color)

sprite1 = Box(100, 150, (255, 0, 0))
sprite2 = Box(350, 150,(0, 0, 255))

all_sprite = 
pygame.sprite.Group()
all_sprite.add(sprite1, sprite2)

running = True
clock = pygame.time.clock()

while running:
  for event in
pygame event.get():
  if event.type ==
pygame.QUIT:
  running = False
   if event.type == 
CHANGE_COLOR:
  
  sprite1.chane_color()
  sprite2.change_color(
    screen.FILL((255, 255, 255))
    all_sprites.draw(screen)
    
    pygame.display.update()
    clock.tick(60)
    
pygame.quit()    
     
     
  
  
  
  
  
                
                
                   
      
      
    
  
